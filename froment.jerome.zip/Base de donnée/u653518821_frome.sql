
-- phpMyAdmin SQL Dump
-- version 3.5.2.2
-- http://www.phpmyadmin.net
--
-- Client: localhost
-- Généré le: Ven 16 Décembre 2016 à 14:48
-- Version du serveur: 10.0.20-MariaDB
-- Version de PHP: 5.2.17

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de données: `u653518821_frome`
--

-- --------------------------------------------------------

--
-- Structure de la table `articles`
--

CREATE TABLE IF NOT EXISTS `articles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `titre` varchar(150) NOT NULL,
  `texte` text NOT NULL,
  `date` date NOT NULL,
  `publie` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=41 ;

--
-- Contenu de la table `articles`
--

INSERT INTO `articles` (`id`, `titre`, `texte`, `date`, `publie`) VALUES
(32, 'Churchill', '  Winston Churchill est célèbre dans la monde entier pour être l''homme qui a tenu tête Hitler même quand son pays s''est fait massacrer. Bon c''était loin d''être un saint évidemment et ce top n''est pas là pour le célébrer ni lui vouer un culte. par contre, peu importe ce qu''on pense du bonhomme on ne peut que s''incliner face à sa rhétorique légendaire. Fallait pas le chauffer en débat le Winstou parce que des bons mots il en avait sous le coude. ', '2016-12-12', 1),
(31, 'De gaulle', '  Car la France n''est pas seule ! Elle n''est pas seule ! Elle n''est pas seule ! Elle a un vaste Empire derrière elle. Elle peut faire bloc avec l''Empire britannique qui tient la mer et continue la lutte. Elle peut, comme l''Angleterre, utiliser sans limites l''immense industrie des Etats-Unis.', '2016-12-12', 1),
(39, 'Cléopatre', '  Nom de sept reines d''Égypte dont\r\nla plus célèbre fut Cléopâtre VII (Alexandrie 69 avant J.-C.-Alexandrie 30 avant J.-C.), reine de 51 à 30 avant J.-C., lors de la conquête romaine, fille de Ptolémée XII Aulète.\r\n\r\nHéritière des Ptolémées, (Lagides) et dernière reine d’Égypte, Cléopâtre VII Philopator est l’une des figures féminines les plus connues de l’histoire. On lui prête un pouvoir de séduction hors du commun, qui ne doit pas éclipser le rôle déterminant qu’elle a tenu pour restaurer la grandeur de son royaume. Plus attachée à l''Égypte qu''aucun de ses prédécesseurs étrangers, Cléopâtre fut la première reine grecque à parler l''égyptien, à adopter certaines croyances pharaoniques et à vouloir rendre à l''Égypte la place qu''elle avait auparavant occupée pendant des siècles. Sa politique, traditionaliste à l''intérieur, audacieuse à l''extérieur, fut constamment soutenue par le peuple égyptien, dont elle avait renforcé le nationalisme et l''orgueil. Intelligente et ambitieuse, elle était, dit-on, d''une beauté remarquable qu''elle sut, à l''occasion, user comme atout dans son jeu politique. ', '2016-12-13', 1),
(40, 'Le chevalier d''Eon', 'Le 5 octobre 1728, Françoise de Charanton donne un enfant à son époux, Louis d''Éon de Beaumont –qui est directeurchevalier_d_Eon des domaines du roi. L’enfant est baptisé Charles-Geneviève-Louise-Auguste-Andrée-Thimothée. Chose étrange pour un garçon d’avoir trois prénoms masculins et trois féminins ! Car pour tout le monde, il s’agit bien d’un fils. Le jeune Charles-Geneviève commence ses études en 1743 à Tonnerre dans sa Bourgogne natale avant d’intégrer le collège Mazarin à Paris. Diplômé de droit en 1749, Charles-Geneviève devient avocat au Parlement de Paris. Remarqué par Louis XV après ses écrits « Considérations Historiques et Politiques », il est nommé censeur royal pour l’Histoire et les belles lettres. Parallèlement, le jeune d’Eon de Beaumont apprend l’escrime et devient un bon cavalier. En 1755, Louis-François Ier de Bourbon-Conti charge le chevalier d’Eon d’une mission secrète auprès de la Tsarine de Russie  Elisabeth Ire. La France souhaite une alliance avec la Russieet Charles-Geneviève a pour rôle de séduire et de gagner la confiance de la Tsarine. Afin qu’Elisabeth Ire se sente plus proche de son espion, le prince de Conti décide de travestir le chevalier d’Eon qui devient Mlle Lya de Beaumont. Gagnant la confiance  la Tsarine, Mlle de Beaumont devient l’une de ses intimes et sa lectrice. C’est à son retour en France que les gens commencent à se poser  des questions sur le chevalier : Charles-Geneviève a trop bien joué son rôle de femme pour n’être qu’un travesti. De plus, on ne connaît  au jeune Beaumont aucune amourette ni fiancée alors qu’il passe pour être un fort bel homme. Il s’appelle Charles certes mais également Geneviève ! De 1758 à 1760, le chevalier est de nouveau en Russie où il passe pour une femme. Il parcourt l’Europe pour mener à bien des missions confiées par Louis XV mais il est tantôt habillé en homme, tantôt en femme. A son retour à Paris en 1760, Charles-Geneviève devient capitaine des Dragons et reçoit la croix du Saint-Esprit. Durant deux ans, il s’illustre au combat et les rumeurs sur sa féminité cessent : une femme ne peut se battre de la sorte et recevoir des commandements de la part du roi. En 1762, le chevalier d’Eon quitte l’armée pour reprendre son rôle d’agent secret en Angleterre à Londres où il travaille pour la politique de Louis XV. Selon les intrigues qu’il doit mener, le chevalier d’Eon se présente en homme ou en femme. Les anglais, perplexes face à cet étrange chevalier d’Eon  se mettent à parier sur son sexe si bien qu’en 1771, le montant parié atteint 300.000 livresMlle__Eon_Beaumont sterling ! Louis XV demande alors en 1774 à Charles-Geneviève de mettre un terme aux rumeurs et de déclarer s’il est un homme ou une jolie demoiselle. Le chevalier signe alors une proclamation dans laquelle il annonce être de sexe féminin. Cette constatation est établie et approuvée par plusieurs médecins. Dés lors, le roi ordonne à Charles-Geneviève de conserver ses vêtements féminins et de ne plus apparaître travesti en homme. Le chevalier d’Eon devient donc officiellement Mlle d’Eon. Il aura fallu des négociations de quatorze mois pour faire admettre au chevalier son sexe moyennant une rente. Etant une femme, Charles-Geneviève n’a plus accès à l’armée, aux affaires politiques et à la diplomatie. Devenant inactive, la jeune femme demande à Louis XV la permission de pouvoir à nouveau porter des vêtements d’hommes. Louis XV n’a pas envie que Mlle d’Eon de Beaumont soit de nouveau au milieu des rumeurs concernant son sexe et refuse. Après la mort de Louis XV, Mlle d’Eon de Beaumont renouvelle sa requête auprès de Louis XVI. C’est ainsi qu’en 1777, vêtue de son uniforme de capitaine des dragons, Charles-Geneviève supplie le roi de lui permettre d’user de nouveau de sa personnalité masculine. Mais Louis XVI soutenu par son ministre Maurepas campe sur les positions de son prédécesseur. Après un exil en Tonnerre, Charles-Geneviève repart pour Londres en 1785 où elle mène une vie de lady avant de perdre sa rente octroyé par le roi de France. Même après la révolution française et la mort de Louis XVI, la vieille Mlle d’Eon de Beaumont ne reprendra pas l’habit d’homme, sans doute résignée à être ce qu’elle a toujours été : une femme. Son père, déçu de ne pas avoir eu de fils avait-il dés la naissance de la petite Charles-Geneviève fait de sa fille un garçon ?  Cette hypothèse est retenue et on imagine que Mlle d’Eon qui avait été habituée et élevée en tant qu’homme avait voulu revenir à cette personnalité après 1774. Le 21 mai 1810, l’ex chevalier d’Eon s’éteint. Oubliée de tous, Charles-Geneviève était morte dans la misère. Lors de la toilette funéraire, les médecins et une quinzaine de personnes s’aperçoivent que la vieille dame était en fait…un homme ! Retournement incroyable de situation ! En 1774, le chevalier d’Eon avait pourtant affirmé être une femme et plusieurs médecins avaient confirmé ses dires. Pourquoi donc Charles-Geneviève a-t-il accepté d’être une femme durant quarante années ? Louis XV et Louis XVI étaient-ils aule_chevalier_d__Eon courant que Mlle d’Eon était en fait de sexe masculin ? Dans ce cas, pourquoi ont-ils refusé qu’elle redevienne un homme ? Après la mort de Louis XVI, pourquoi donc le chevalier d’Eon n’a-t-il pas reprit sa véritable identité ? Le 23 mai, un des membres de la faculté d’Angleterre déclara : « Par la présente, je certifie que j''ai examiné et disséqué le corps du chevalier d''Éon et que j''ai trouvé sur ce corps les organes mâles de la génération parfaitement formés sous tous les rapports ». Mais qui sait….si ces quelques personnes présentes autour de la dépouille de Charles-Geneviève s’étaient mises d’accord pour affirmer qu’il était un homme alors que c’était en réalité une femme ? Car pourquoi le chevalier d’Eon aurait-il menti sur son sexe féminin ? Le mystère demeure…  ', '2016-12-16', 1);

-- --------------------------------------------------------

--
-- Structure de la table `commentaire`
--

CREATE TABLE IF NOT EXISTS `commentaire` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_article` int(11) NOT NULL,
  `pseudo` text NOT NULL,
  `date` date NOT NULL,
  `texte` text NOT NULL,
  `email` varchar(150) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=25 ;

--
-- Contenu de la table `commentaire`
--

INSERT INTO `commentaire` (`id`, `id_article`, `pseudo`, `date`, `texte`, `email`) VALUES
(2, 32, 'jerome', '2016-12-13', 'c''est intéressant ', ''),
(3, 32, 'david', '2016-12-13', 'Super article', ''),
(4, 32, 'gerard', '2016-12-13', 'Je suis toujours prêt à apprendre, bien que je n''aime pas toujours qu''on me donne des leçons.', ''),
(5, 32, 'thomas', '2016-12-13', 'c''est un citation de winston churchill ?', ''),
(6, 32, 'gerard', '2016-12-13', 'Oui ;)', ''),
(7, 31, 'victor', '2016-12-13', 'L''appel du Généra De Gaulle', ''),
(8, 32, 'jerome', '2016-12-13', 'C''est un grand Homme avec un grand H', ''),
(14, 32, 'jerome', '2016-12-14', 'c''est super', ''),
(22, 32, 'jerome', '2016-12-16', 'test verif email', 'jerome@gmail.com'),
(23, 32, 'jerome', '2016-12-16', 'test', ''),
(24, 32, 'victor', '2016-12-16', 'test email abs', '');

-- --------------------------------------------------------

--
-- Structure de la table `utilisateurs`
--

CREATE TABLE IF NOT EXISTS `utilisateurs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(50) NOT NULL,
  `prenom` varchar(50) NOT NULL,
  `email` varchar(150) NOT NULL,
  `mdp` text NOT NULL,
  `sid` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=16 ;

--
-- Contenu de la table `utilisateurs`
--

INSERT INTO `utilisateurs` (`id`, `nom`, `prenom`, `email`, `mdp`, `sid`) VALUES
(1, 'froment', 'jerome', 'jerome.froment62130@gmail.com', 'jerome', 'e3c16a292485eb0b80c4be230847d4d8'),
(14, 'SAGARY', 'Victor', 'victor.sagary@hotmail.fr', 'victor', 'bbba6796b2bcaa37e47c65d6301e2fa1'),
(6, 'froment', 'jeremie', 'jeremie@froment.fr', 'froment', '293bfcbb00fdad31a8d35409fc60d191'),
(15, 'mug', 'rom', 'rom.mug@caramail.fr', 'calais', 'a92287443f35314d2d8161b11dac8fff'),
(7, 'guilbert', 'francois', 'francois@gil.com', 'mobile', '050d9056a06150b2d2df652e418be864'),
(13, 'fromant', 'damien', 'dami@g.f', 'damien', 'bd480023d3c4cde5099865e12055fd8f');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
