<?php 
$connect=false;
error_reporting(E_ALL);
ini_set("display_error",1);
