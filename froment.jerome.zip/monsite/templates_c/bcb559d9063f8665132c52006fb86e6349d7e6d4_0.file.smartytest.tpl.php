<?php
/* Smarty version 3.1.30, created on 2016-11-21 12:32:21
  from "C:\wamp64\www\monsite\templates\smartytest.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_5832e95573aba3_60341699',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'bcb559d9063f8665132c52006fb86e6349d7e6d4' => 
    array (
      0 => 'C:\\wamp64\\www\\monsite\\templates\\smartytest.tpl',
      1 => 1479731474,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5832e95573aba3_60341699 (Smarty_Internal_Template $_smarty_tpl) {
?>
<p>Bonjour <?php echo $_smarty_tpl->tpl_vars['name']->value;?>
 </p><?php }
}
