<!DOCTYPE html>
<html lang="fr">
  <head>
    <meta charset="utf-8">
    <title>Le blog de Froment Jérôme</title>
    <meta name="description" content="Petit blog pour m'initier à PHP">
    <meta name="author" content="Votre Nom">

    <!-- Le HTML5 shim, for IE6-8 support of HTML elements -->
    <!--[if lt IE 9]>
      <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->
    
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/main.css" rel="stylesheet">
    <script type="text/javascript" src="js/jquery.js"></script>
  </head>

  <body>
  
    <div class="container">

      <div class="content">
      
        <div class="page-header well">
          <h1>Le Blog Jérôme Froment <small>Pour m'initier à PHP</small></h1>
        </div>
        
        <div class="row">

